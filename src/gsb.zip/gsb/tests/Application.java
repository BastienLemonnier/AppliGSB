/*
 * Cr�� le 22 f�vr. 2015
 *
 * TODO Pour changer le mod�le de ce fichier g�n�r�, allez � :
 * Fen�tre - Pr�f�rences - Java - Style de code - Mod�les de code
 */
package gsb.tests;

import gsb.vue.MenuPrincipal;

/**
 * @author Isabelle
 * 22 f�vr. 2015
 */
public class Application
{
	public static void main(String[] args)
	{
		new MenuPrincipal();
	}
}