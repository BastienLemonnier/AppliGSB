/**
 *
 * Cr�� le 18 nov. 2021
 *
 */
package gsb.tests.service;

import junit.framework.TestCase;

/**
 * @author LEMONNIER Bastien
 * 18 nov. 2021
 *
 */
public class VisiteurServiceTest extends TestCase {
	
}
